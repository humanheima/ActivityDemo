## 启动 jekins

brew services start jenkins-lts

## 重启

brew services restart jenkins-lts

cat /Users/xmly/.jenkins/secrets/initialAdminPassword


### 移动研发平台查看构建日志的账号和密码

账号  ： rn  
密码： password!


### 打包平台上的参数是如何影响到打包的。

1. 在根目录的build.gradle文件中应用了config.gradle

```
apply from: "config.gradle"
```

2. config.gradle声明了需要动态修改的属性。并且会根据构建命令传递过来的参数动态设置这些属性值。

```groovy

ext {
     //...

    useMaven = false
    uploadMaven = false
    createHostPatch = false
    javaCompileVersion = JavaVersion.VERSION_1_8

    versionCode = "170"
    versionName = "3.0.5.0"

    compileSdkVersion = 29
    buildToolsVersion = "28.0.3"
    minSdkVersion = "18"
    targetSdkVersion = "26"

    openBlockCanary = "false"  //是否开启BlockCanary
    generate_public_xml = false
    openLeakCanary = "true"  //是否开启LeakCanary
    openLogView = "true"    //是否开启log日志展示
    //extChannels = "and-d3"//不能命名test/debug等字段开头
    channel = "and-f5-ocpa"// 开发时渠道改为 ceshi
    needChannel = "false"  //生成的apk中是否需要加入渠道信息
    modifyApplicationName = "false"  //是否需要修改应用名称
    applicationName = "喜马拉雅极速版"
    //pChannels shell 输入参数
    shallReadChannelfromFile = "false"
    isProguard = "false"
    isReleaseDebug = "true"
    //注释1处，控制是否输出gradle 调试信息
    isDebugGradle = "true" 
    isBundleDevMode = "false"

    isOpenAutoTrace = "true" // 是否打开自动埋点
    isOpenPointSdk = "true" // 是否打入 可视化埋点sdk （一般不需要打开）
    serverType = "2" // 埋点服务器类型，用于选择不同的埋点服务器类型（2 正式服，1 uat （稳定测试服），3 测试服；）

    isDemo = "false"

    openLogSpirit = "false" // 是否打开日志回捞编译时操作


    openStetho = false
    createBaseJar = "true"
    createPatchJar = "false"

//    proguardLableDir = "XAndroidFramework"// 混淆标志文件，在有多级transform编译时
    commResPath = project(':TingMainHost:TingMainApp').getProjectDir().absolutePath + File.separator + "constant-resource"
    println "==========================================>commResPath:" + commResPath
    //只有引用了providedhost才需要把configurationType的值设置为archives，这样可以分析依赖，否则直接留空，正常项目如果使用了archives会导致libs里面的jar重复引用
    if (BUILD_PLUGIN_APK.toBoolean()) {
        configurationType = 'archives'
    } else {
        configurationType = ''
    }
    //是否应用以前的混淆mapping文件
    shouldApplyLastMapping = false
    //是否应用public.xml
    shouldApplyPublicXml = false
    //是否将application生成的Mapping拷贝到bundle project中
    isCopyApplicationMappingToBundleProject = false
    isBuildCommonRes = false;
    //全量编译整个项目，生成混淆的mapping文件，用来支持各个bundle独立编译保持混淆的一致性，此开关打开后，Gradle脚本会忽略一些和生成混淆无关的task,从而加快编译速度
    isBuildAllProjectOnlyForProguardMapping = false;
    hostPackageName = "com.ximalaya.ting.lite"
    hostBundleVersion = "135.0"

    buildNumber = "LocalBuild"

    resProguardMapping = null
}

if (rootProject.isDebugGradle.toBoolean()) {
    println "=====================set ext property start====================="
}

//注释2处，修改已经声明的 versionCode 值，
if (project.hasProperty('pVersionCode')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("int config.gradle set pVersionCode")
    }
    rootProject.versionCode = project.property('pVersionCode')
}

if (project.hasProperty('pVersionName')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pVersionName")
    }
    rootProject.versionName = project.property('pVersionName')
}

if (project.hasProperty('pIsProguard')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pIsProguard")
    }
    rootProject.isProguard = project.property('pIsProguard')
}

if (project.hasProperty('pIsReleaseDebug')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pIsReleaseDebug")
    }
    rootProject.isReleaseDebug = project.property('pIsReleaseDebug')
}

if (project.hasProperty('pNeedChannel')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pNeedChannel")
    }
    rootProject.needChannel = project.property('pNeedChannel')
}

if (project.hasProperty('pModifyApplicationName')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pModifyApplicationName")
    }
    rootProject.modifyApplicationName = project.property('pModifyApplicationName')
}

if (project.hasProperty('pApplicationName')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pApplicationName")
    }
    rootProject.applicationName = project.property('pApplicationName')
}

if (project.hasProperty('pCreateBaseJar')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pCreateBaseJar")
    }
    rootProject.createBaseJar = project.property('pCreateBaseJar')
}

if (project.hasProperty('pCreatePatchJar')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pCreatePatchJar")
    }
    rootProject.createPatchJar = project.property('pCreatePatchJar')
}

if (project.hasProperty('pShouldApplyPublicXml')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pShouldApplyPublicXml")
    }
    rootProject.shouldApplyPublicXml = project.property('pShouldApplyPublicXml')
}

if (rootProject.isDebugGradle.toBoolean()) {
    println "=====================set ext property end====================="
}

if (project.hasProperty('pIsOpenPointSdk')) {
    println(" point trace sdk----------------------------------")
    rootProject.isOpenPointSdk = project.property('pIsOpenPointSdk')
}

if (project.hasProperty('pIsBundleDevMode')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pIsBundleDevMode")
    }
    rootProject.isBundleDevMode = project.property('pIsBundleDevMode')
}

if (project.hasProperty('pIsOpenAutoTrace')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("set pIsOpenAutoTrace")
    }
    rootProject.isOpenAutoTrace = project.property('pIsOpenAutoTrace')
}

if (project.hasProperty('pHostPackageName')) {
    rootProject.hostPackageName = project.property('pHostPackageName')
    println("set pHostPackageName")
}

if (project.hasProperty('pBuildNumber')) {

    rootProject.buildNumber = project.property('pBuildNumber')
    println("set pBuildNumber " + rootProject.buildNumber)
}
//...


```

注释1处，控制是否输出gradle 调试信息，这个可以设置为true。在构建的时候可以输出动态变量的设置。



```groovy

//注释2处，修改已经声明的 versionCode 值，
if (project.hasProperty('pVersionCode')) {
    if (rootProject.isDebugGradle.toBoolean()) {
        println("int config.gradle set pVersionCode")
    }
    //根据脚本中传递的pVersionCode参数，修改默认的versionCode值，在这个例子中默认值设置的是3.0.5.0
    rootProject.versionCode = project.property('pVersionCode')
}

```

构建脚本

```jshelllanguage
./gradlew -PpModifyApplicationName=true -PpApplicationName=喜马拉雅极速版 -PpVersionName=3.0.5.0 -PpVersionCode=124 -PpHostPackageName=com.ximalaya.ting.lite -PpIsReleaseDebug=true -PpIsProguard=true -PpShouldApplyPublicXml=true -PpIsBundleDevMode=false -PpIsOpenAutoTrace=false -PpIsOpenPointSdk=false -PpResProguardMapping= :TingMainHost:Application:resguardRelease --stacktrace
```



