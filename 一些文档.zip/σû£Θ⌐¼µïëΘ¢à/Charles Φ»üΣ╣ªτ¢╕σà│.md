Charles代理相关

Charles版本：4.5.6


Charles选择 Help -> SSL Proxying -> Install Charles Root Certificate

将证书选择永远信任(Always trust)


2. Charles选择 Help -> SSL Proxying -> Install Charles Root Certificate  on a Mobile Device or Remote Broswer.

Vivo手机下载了证书，要把后缀名`.pem`改为`.crt`才能正确安装。

