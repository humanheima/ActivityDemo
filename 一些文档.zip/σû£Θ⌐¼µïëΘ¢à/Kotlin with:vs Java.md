Kotlin with/vs Java 

* 不用写分号；
* 创建对象不需要使用 new 关键字。
### 变量

不可变量
```kotlin
val a: Int = 1  // 立即赋值
val b = 2   // 自动推断出 `Int` 类型
val c: Int  // 如果没有初始值类型不能省略
c = 3       // 明确赋值
```

可变变量

```kotlin
var x = 5 // 自动推断出 `Int` 类型
x += 1
```

### 函数

```
fun sum(a: Int, b: Int): Int {
    return a + b
}

//表达式函数
fun sum(a: Int, b: Int) = a + b

//无返回类型的函数
fun printSum(a: Int, b: Int) {
    println("sum of $a and $b is ${a + b}")
}
```

#### 函数的默认参数，减少代码量

```kotlin
/**
 * 带默认参数的方法，为了能在Java中调用，需要使用 @JvmOverloads 注解
 */
@JvmOverloads
fun <T> joinToStringWithDefaultArgs(
    collection: Collection<T>, separator: String = ", ", prefix: String = "",
    postfix: String = ""
): String {
    val result = StringBuilder(prefix)
    for ((index, element) in collection.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(element)
    }
    result.append(postfix)
    return result.toString()
}
```

在Kotlin 中调用

```
fun main(args: Array<String>) {
    val list = listOf(1, 2, 3)
  
    println(joinToStringWithDefaultArgs(list))
    println(joinToStringWithDefaultArgs(list, ","))
    println(joinToStringWithDefaultArgs(list, ";", "(", ")"))
    println(joinToStringWithDefaultArgs(list, separator = ";", postfix = ")"))
    println(joinToStringWithDefaultArgs(list, separator = ";", prefix = "(", postfix = ")"))
}
```

在Java中调用

```java
public static void main(String[] args) {

        List<String> list = new ArrayList<>();

        list.add("1");
        list.add("2");
        list.add("3");

        StringFunctions.joinToStringWithDefaultArgs(list);
        StringFunctions.joinToStringWithDefaultArgs(list,",");
        StringFunctions.joinToStringWithDefaultArgs(list,",","{");
        StringFunctions.joinToStringWithDefaultArgs(list,",","{","}");

    }
```
### 字符串模板

```
var a = 1
// 模板中的简单名称：
val s1 = "a is $a" 

a = 2
// 模板中的任意表达式：s1调用String的replace方法
val s2 = "${s1.replace("is", "was")}, but now is $a" //s2 =a was 1, but now is 2
```

### 类型检测与自动类型转换

在Java中使用了 instanceOf以后，还是需要强制转换成对应的类型。

`is` 运算符检测一个表达式是否某类型的一个实例。 如果一个不可变的局部变量或属性已经判断出为某类型，那么检测后的分支中可以直接当作该类型使用，无需显式转换：

```kotlin
fun getStringLength(obj: Any): Int? {
    if (obj is String) {
        // `obj` 在该条件分支内自动转换成 `String`
        return obj.length
    }

    // 在离开类型检测分支后，`obj` 仍然是 `Any` 类型
    return null
}
```

### 集合查找

```kotlin
fun main() {
    val items = setOf("apple", "banana", "kiwifruit")
    when {
        "orange" in items -> println("juicy")
        "apple" in items -> println("apple is fine too")
    }
}
```

```kotlin
fun main() {
  val fruits = listOf("banana", "avocado", "apple", "kiwifruit")
  fruits
    .filter { it.startsWith("a") }
    .sortedBy { it }
    .map { it.toUpperCase() }
    .forEach { println(it) }
}
```

### 安全调用和Elvis运算符

```kotlin
fun printAllCaps(s: String?) {
    //如果s是null的话，不会执行String的toUpperCase方法
    val allCaps: String? = s?.toUpperCase()
    println(allCaps)
}
```

Elvis运算符 `?:`

```kotlin
fun printAllCaps(s: String?) {
    //左边的表达式为null则取右边的值
    val allCaps: String = s?.toUpperCase()?:"unknown"
    println(allCaps)
}
```

```
fun printAllCaps(s: String?) {
    //左边的表达式为null，直接返回，不执行下面的代码
    val allCaps: String = s?.toUpperCase()?:return
    println(allCaps)
}
```

### Kotlin的类型系统

Kotlin和 Java 的类型系统之间第一条也可能是最重要的一条区别是，Kotlin对可空类型的显式的支持。这意味着什么呢？这是一种指出你的程序中哪些变量和属性允许为null的方式。

#### 非空类型

Kotlin中所有常见的的类型都是非空类型：String、 Int、 MyCustomType，等等类型的变量不能存储null引用。

#### 可空类型

将问号加在任何类型的后面来表示这个类型的变量可以存储null引用：String ？、 Int ？、 MyCustomType ？，等等。

### 平台类型

平台类型本质上就是 Kotlin 不知道可空性信息的类型。既可以把它当作可空类型处理， 也当作非空类型处理理。这意味着，你要像在 Java 样，对你在这个类型上做 操作负有全部责任。

![平台可控性](/Users/xmly/Downloads/博客相关文件/平台可空性.png)


### 集合

#### 不可变集合

不可变集合，没有addXXX方法
```kotlin
fun test() {
    val list: List<String> = listOf("a", "b", "c")
    val map: Map<String, String> = mapOf("key" to "value", "key1" to "value1")
}
```

#### 可变集合

```
fun test() {
   
    val mutableList: MutableList<String> = arrayListOf("a", "b", "c")
    mutableList.add("d")
    mutableList.add("e")
    mutableList.add("f")

    val hashMap: HashMap<String, String> = hashMapOf()
    hashMap["key"] = "value"

}
```










