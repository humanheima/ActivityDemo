cbf5e222-d5ea-3d49-80bd-aebaba0eb5cf

2021-09-13 10:25:32.376 893-1728/? E/qdmetadata: paramType 2048 not supported
2021-09-13 10:25:32.379 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.387 7858-7882/com.ximalaya.ting.lite W/System.err: java.lang.IllegalArgumentException: Receiver not registered: com.ximalaya.ting.android.opensdk.util.MultiProcessSharedPreferences$1@e4a59e9
2021-09-13 10:25:32.387 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.app.LoadedApk.forgetReceiverDispatcher(LoadedApk.java:1439)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.app.ContextImpl.unregisterReceiver(ContextImpl.java:1652)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.content.ContextWrapper.unregisterReceiver(ContextWrapper.java:726)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.opensdk.util.MultiProcessSharedPreferences.registerOnSharedPreferenceChangeListener(MultiProcessSharedPreferences.java:239)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.host.manager.account.UserInfoMannage.<init>(UserInfoMannage.java:100)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.host.manager.account.UserInfoMannage.<clinit>(UserInfoMannage.java:94)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.host.manager.account.UserInfoMannage.getUid(UserInfoMannage.java:294)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.host.manager.statistic.UserOneDataOperatingSPContentProvider.query(UserOneDataOperatingSPContentProvider.java:78)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.content.ContentProvider.query(ContentProvider.java:1402)
2021-09-13 10:25:32.388 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.content.ContentProvider.query(ContentProvider.java:1498)
2021-09-13 10:25:32.389 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.content.ContentProvider$Transport.query(ContentProvider.java:278)
2021-09-13 10:25:32.389 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.content.ContentProviderNative.onTransact(ContentProviderNative.java:106)
2021-09-13 10:25:32.389 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.os.Binder.execTransactInternal(Binder.java:1154)
2021-09-13 10:25:32.389 7858-7882/com.ximalaya.ting.lite W/System.err:     at android.os.Binder.execTransact(Binder.java:1123)
2021-09-13 10:25:32.390 12654-12654/? W/PushService: [Tid:2] onStart() with intent.Action = null, chid = null, pkg = null|com.ximalaya.ting.lite
2021-09-13 10:25:32.392 893-1728/? E/qdmetadata: paramType 2048 not supported
2021-09-13 10:25:32.399 2874-2874/? D/NavBarTintController: onSampleCollected 3.917651E-7
2021-09-13 10:25:32.409 893-1728/? E/qdmetadata: paramType 2048 not supported
2021-09-13 10:25:32.430 7821-7905/com.ximalaya.ting.lite I/SAVE_LIFE: null   null
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err: org.json.JSONException: End of input at character 0 of 
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at org.json.JSONTokener.syntaxError(JSONTokener.java:460)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at org.json.JSONTokener.nextValue(JSONTokener.java:101)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at org.json.JSONObject.<init>(JSONObject.java:165)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at org.json.JSONObject.<init>(JSONObject.java:182)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.host.manager.request.CommonRequestM$8.onResponse(CommonRequestM.java:1000)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.opensdk.httputil.BaseCall$2.onResponse(BaseCall.java:337)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at okhttp3.RealCall$AsyncCall.execute(RealCall.java:206)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at okhttp3.internal.NamedRunnable.run(NamedRunnable.java:32)
2021-09-13 10:25:32.431 7821-7905/com.ximalaya.ting.lite W/System.err:     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
2021-09-13 10:25:32.432 7821-7905/com.ximalaya.ting.lite W/System.err:     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
2021-09-13 10:25:32.432 7821-7905/com.ximalaya.ting.lite W/System.err:     at java.lang.Thread.run(Thread.java:923)
2021-09-13 10:25:32.471 604-604/? E/SELinux: avc:  denied  { find } for pid=4536 uid=10266 name=tethering scontext=u:r:vendor_systemhelper_app:s0:c512,c768 tcontext=u:object_r:tethering_service:s0 tclass=service_manager permissive=0
2021-09-13 10:25:32.478 7821-7854/com.ximalaya.ting.lite D/fuli====: main: 保存服务器时间==localDate=20210913  curServiceTime=20210913
2021-09-13 10:25:32.484 7858-7858/com.ximalaya.ting.lite E/启动时间AppManager:: 重置耗时计算，开始计时
2021-09-13 10:25:32.485 7858-7858/com.ximalaya.ting.lite D/ximalaya: umeng preinit start
2021-09-13 10:25:32.489 7821-7884/com.ximalaya.ting.lite D/DBMultiProviderImpl: update: content://com.ximalaya.ting.lite.TTMultiProvider/t_db/ttopensdk.db/setting_global_info
2021-09-13 10:25:32.494 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: AndroidManifest.xml中TTMultiProvider配置正常
2021-09-13 10:25:32.494 7821-7884/com.ximalaya.ting.lite D/SettingRitRepertoryImpl: insertOrUpdateGlobalInfo -- key:3; value:1
2021-09-13 10:25:32.502 12654-12654/? W/PushService: [Tid:2] onStart() with intent.Action = com.xiaomi.mipush.SEND_MESSAGE, chid = null, pkg = null|com.ximalaya.ting.lite
2021-09-13 10:25:32.502 12654-12705/? W/PushService: [Tid:5007] [Job] Handle intent action = com.xiaomi.mipush.SEND_MESSAGE
2021-09-13 10:25:32.503 7821-7914/com.ximalaya.ting.lite W/XMPush-7821: [Tid:2698] begin execute onNotificationMessageClicked from　scm58940631499892906do
2021-09-13 10:25:32.503 7821-7914/com.ximalaya.ting.lite I/DelegatePushReceiver: onNotificationMessageClicked invoke: 
2021-09-13 10:25:32.503 12654-12705/? W/PushService: [Tid:5007] try send mi push message. packagename:com.ximalaya.ting.lite action:Notification
2021-09-13 10:25:32.507 7821-7884/com.ximalaya.ting.lite D/DBMultiProviderImpl: query: content://com.ximalaya.ting.lite.TTMultiProvider/t_db/ttopensdk.db/setting_global_info
2021-09-13 10:25:32.512 7821-7884/com.ximalaya.ting.lite D/DBMultiProviderImpl: update: content://com.ximalaya.ting.lite.TTMultiProvider/t_db/ttopensdk.db/setting_global_info
2021-09-13 10:25:32.532 7858-7858/com.ximalaya.ting.lite I/MyAsyncTask: MyAsyncTask --- myexec com.ximalaya.ting.android.host.manager.request.HttpDNSLibManager$1@98dc91b
2021-09-13 10:25:32.542 7821-7951/com.ximalaya.ting.lite I/XmPushManager: pushClick: mInitConfig == null
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err: java.lang.NullPointerException: Attempt to invoke virtual method 'int org.json.JSONObject.getInt(java.lang.String)' on a null object reference
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err:     at com.ximalaya.ting.android.xmpushservice.model.PushStat$PushClickStat.run(PushStat.java:357)
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err:     at android.os.Handler.handleCallback(Handler.java:938)
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err:     at android.os.Handler.dispatchMessage(Handler.java:99)
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err:     at android.os.Looper.loop(Looper.java:236)
2021-09-13 10:25:32.543 7821-7951/com.ximalaya.ting.lite W/System.err:     at android.os.HandlerThread.run(HandlerThread.java:67)
2021-09-13 10:25:32.549 7858-7858/com.ximalaya.ting.lite W/ing.lite:playe: Accessing hidden method Ldalvik/system/CloseGuard;->get()Ldalvik/system/CloseGuard; (greylist,core-platform-api, reflection, allowed)
2021-09-13 10:25:32.550 7858-7858/com.ximalaya.ting.lite W/ing.lite:playe: Accessing hidden method Ldalvik/system/CloseGuard;->open(Ljava/lang/String;)V (greylist,core-platform-api, reflection, allowed)
2021-09-13 10:25:32.550 7858-7858/com.ximalaya.ting.lite W/ing.lite:playe: Accessing hidden method Ldalvik/system/CloseGuard;->warnIfOpen()V (greylist,core-platform-api, reflection, allowed)
2021-09-13 10:25:32.556 604-604/? E/SELinux: avc:  denied  { find } for pid=5495 uid=10064 name=tethering scontext=u:r:permissioncontroller_app:s0:c64,c256,c512,c768 tcontext=u:object_r:tethering_service:s0 tclass=service_manager permissive=0
2021-09-13 10:25:32.557 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker:     可能缺少权限：android.permission.ACCESS_COARSE_LOCATION，请参考接入文档
2021-09-13 10:25:32.557 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker:     可能缺少权限：android.permission.ACCESS_FINE_LOCATION，请参考接入文档
2021-09-13 10:25:32.563 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，permission：android.permission.READ_PHONE_STATE
2021-09-13 10:25:32.564 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，locationOp,permission：0,android:read_phone_state
2021-09-13 10:25:32.565 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，permission：android.permission.ACCESS_COARSE_LOCATION
2021-09-13 10:25:32.568 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 5,6,7
2021-09-13 10:25:32.569 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 8,9,10,com.ximalaya.ting.lite
2021-09-13 10:25:32.571 7858-7954/com.ximalaya.ting.lite I/MyAsyncTask: MyAsyncTask --- myexec com.ximalaya.ting.android.host.manager.request.HttpDNSLibManager$2@35dbf7
2021-09-13 10:25:32.573 7821-7895/com.ximalaya.ting.lite I/UMConfigure: common version is 9.4.2.A
2021-09-13 10:25:32.574 7821-7895/com.ximalaya.ting.lite I/UMConfigure: common type is 0
2021-09-13 10:25:32.588 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Verification of int yaq.pro.preparefiles(java.lang.String) took 108.678ms (113785.44 bytecodes/s) (269320B approximate peak alloc)
2021-09-13 10:25:32.590 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden method Landroid/app/ActivityThread;->currentActivityThread()Landroid/app/ActivityThread; (greylist, reflection, allowed)
2021-09-13 10:25:32.590 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden method Landroid/app/ActivityThread;->getApplication()Landroid/app/Application; (greylist, reflection, allowed)
2021-09-13 10:25:32.590 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Ldalvik/system/BaseDexClassLoader;->pathList:Ldalvik/system/DexPathList; (greylist, reflection, allowed)
2021-09-13 10:25:32.590 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Ldalvik/system/DexPathList;->dexElements:[Ldalvik/system/DexPathList$Element; (greylist, reflection, allowed)
2021-09-13 10:25:32.596 7858-7858/com.ximalaya.ting.lite W/ing.lite:playe: Accessing hidden field Landroid/app/ActivityManager;->IActivityManagerSingleton:Landroid/util/Singleton; (greylist, reflection, allowed)
2021-09-13 10:25:32.596 7858-7858/com.ximalaya.ting.lite W/ing.lite:playe: Accessing hidden field Landroid/util/Singleton;->mInstance:Ljava/lang/Object; (greylist, reflection, allowed)
2021-09-13 10:25:32.607 7821-7912/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden method Ljava/lang/Runtime;->nativeLoad(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/String; (greylist, reflection, allowed)
2021-09-13 10:25:32.602 7821-7821/com.ximalaya.ting.lite W/pool-8-thread-1: type=1400 audit(0.0:320044): avc: granted { execute } for path="/data/user/0/com.ximalaya.ting.lite/app_e_qq_com_plugin_d0a51f89c3649dd35796abfcd8c88b74/libyaqpro.2ec77435.so" dev="dm-10" ino=429696 scontext=u:r:untrusted_app_27:s0:c512,c768 tcontext=u:object_r:app_data_file:s0:c512,c768 tclass=file app=com.ximalaya.ting.lite
2021-09-13 10:25:32.612 7821-7821/com.ximalaya.ting.lite W/pool-8-thread-1: type=1400 audit(0.0:320045): avc: granted { execute } for path="/data/user/0/com.ximalaya.ting.lite/app_e_qq_com_plugin_d0a51f89c3649dd35796abfcd8c88b74/libyaqbasic.2ec77435.so" dev="dm-10" ino=429697 scontext=u:r:untrusted_app_27:s0:c512,c768 tcontext=u:object_r:app_data_file:s0:c512,c768 tclass=file app=com.ximalaya.ting.lite
2021-09-13 10:25:32.624 7858-7958/com.ximalaya.ting.lite I/url123: http://dns.ximalaya.com/xdns/iplist
2021-09-13 10:25:32.625 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，locationOp,permission：0,android:coarse_location
2021-09-13 10:25:32.622 7821-7821/com.ximalaya.ting.lite W/pool-8-thread-1: type=1400 audit(0.0:320046): avc: granted { execute } for path="/data/user/0/com.ximalaya.ting.lite/app_e_qq_com_plugin_d0a51f89c3649dd35796abfcd8c88b74/libMMANDKSignature.2ec77435.so" dev="dm-10" ino=429698 scontext=u:r:untrusted_app_27:s0:c512,c768 tcontext=u:object_r:app_data_file:s0:c512,c768 tclass=file app=com.ximalaya.ting.lite
2021-09-13 10:25:32.630 7821-7912/com.ximalaya.ting.lite I/TuringFdNative: TuringFD v60 (6AABEDED5976DBC8, au, 7d25e42, lot, compiled 2021_03_30_21_15_57) success 
2021-09-13 10:25:32.622 7821-7821/com.ximalaya.ting.lite W/pool-8-thread-1: type=1400 audit(0.0:320047): avc: granted { execute } for path="/data/user/0/com.ximalaya.ting.lite/app_e_qq_com_plugin_d0a51f89c3649dd35796abfcd8c88b74/libturingau.2ec77435.so" dev="dm-10" ino=429699 scontext=u:r:untrusted_app_27:s0:c512,c768 tcontext=u:object_r:app_data_file:s0:c512,c768 tclass=file app=com.ximalaya.ting.lite
2021-09-13 10:25:32.640 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，permission：android.permission.ACCESS_FINE_LOCATION
2021-09-13 10:25:32.640 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，locationOp,permission：0,android:fine_location
2021-09-13 10:25:32.641 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，permission：android.permission.WRITE_EXTERNAL_STORAGE
2021-09-13 10:25:32.650 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 11,12,13
2021-09-13 10:25:32.650 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 14,15,16
2021-09-13 10:25:32.650 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 17,18,19
2021-09-13 10:25:32.651 7858-7952/com.ximalaya.ting.lite D/ximalaya_exception: 20,21,22=22a001357629de32518a24508149689f
2021-09-13 10:25:32.651 7858-7952/com.ximalaya.ting.lite I/ting: WebUtil_checkTTSEngine 
2021-09-13 10:25:32.654 7821-7851/com.ximalaya.ting.lite I/url123: http://gslbtx.ximalaya.com/linkeye-cloud/httpdns/v3/init/1631499932652?app=lite&appId=9999&device=general&version=1731e
2021-09-13 10:25:32.665 7821-7884/com.ximalaya.ting.lite E/a: checkPermissinKITKATNew，locationOp,permission：0,android:write_external_storage
2021-09-13 10:25:32.667 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: 动态权限正常：android.permission.READ_PHONE_STATE
2021-09-13 10:25:32.667 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: 动态权限正常：android.permission.ACCESS_COARSE_LOCATION
2021-09-13 10:25:32.667 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: 动态权限正常：android.permission.ACCESS_FINE_LOCATION
2021-09-13 10:25:32.667 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: 动态权限正常：android.permission.WRITE_EXTERNAL_STORAGE
2021-09-13 10:25:32.667 7821-7884/com.ximalaya.ting.lite E/TTAdSdk-InitChecker: ==穿山甲sdk初始化配置检测结束==
2021-09-13 10:25:32.671 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.673 604-604/? E/SELinux: avc:  denied  { find } for pid=4536 uid=10266 name=tethering scontext=u:r:vendor_systemhelper_app:s0:c512,c768 tcontext=u:object_r:tethering_service:s0 tclass=service_manager permissive=0
2021-09-13 10:25:32.691 7821-7895/com.ximalaya.ting.lite I/UMConfigure: current appkey is 5d022275570df31369000ccf, last appkey is 5d022275570df31369000ccf
2021-09-13 10:25:32.694 7821-7895/com.ximalaya.ting.lite I/UMConfigure: channel is default
2021-09-13 10:25:32.695 7821-7912/com.ximalaya.ting.lite I/TuringFdJava: TuringFD v60 (6AABEDED5976DBC8, au, 7d25e42, lot, w;105498, compiled 2021_03_30_21_15_57)
2021-09-13 10:25:32.713 7821-7895/com.ximalaya.ting.lite D/UMLog: 统计SDK常见问题索引贴 详见链接 http://developer.umeng.com/docs/66650/cate/66650
2021-09-13 10:25:32.714 7821-7895/com.ximalaya.ting.lite I/UMLog: 统计SDK初始化成功
2021-09-13 10:25:32.726 7821-7895/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Landroid/content/pm/ApplicationInfo;->primaryCpuAbi:Ljava/lang/String; (greylist, reflection, allowed)
2021-09-13 10:25:32.730 7858-7965/com.ximalaya.ting.lite I/HttpDNSInterceptor: useOldPolicy http://dns.ximalaya.com/xdns/iplist
2021-09-13 10:25:32.750 32156-32258/? D/IdProviderImpl: getOAID
2021-09-13 10:25:32.751 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getDeviceId:-1
2021-09-13 10:25:32.757 931-19182/? I/vendor.qti.hardware.servicetracker@1.2-service: bindService is called for service : com.xiaomi.mibrain.speech/.tts.TtsService and for client com.ximalaya.ting.lite:player
2021-09-13 10:25:32.757 931-19182/? I/vendor.qti.hardware.servicetracker@1.2-service: total connections for service : com.xiaomi.mibrain.speech/.tts.TtsServiceare :2
2021-09-13 10:25:32.757 931-19182/? I/vendor.qti.hardware.servicetracker@1.2-service: total connections for client : com.ximalaya.ting.lite:playerare :1
2021-09-13 10:25:32.758 1787-2023/? D/Process: audio-opt: audio thread tid = 698 could not get bg policy.
2021-09-13 10:25:32.759 7858-7858/com.ximalaya.ting.lite I/TextToSpeech: Connected to ComponentInfo{com.xiaomi.mibrain.speech/com.xiaomi.mibrain.speech.tts.TtsService}
2021-09-13 10:25:32.759 32156-32258/? D/IdProviderImpl: getOAID
2021-09-13 10:25:32.766 7858-7952/com.ximalaya.ting.lite I/TextToSpeech: Sucessfully bound to com.xiaomi.mibrain.speech
2021-09-13 10:25:32.792 7858-7929/com.ximalaya.ting.lite I/url123: http://gslbali.ximalaya.com/linkeye-cloud/httpdns/v3/init/1631499932757?app=lite&appId=9999&device=general&version=1731e
2021-09-13 10:25:32.796 604-604/? E/SELinux: avc:  denied  { find } for pid=5495 uid=10064 name=tethering scontext=u:r:permissioncontroller_app:s0:c64,c256,c512,c768 tcontext=u:object_r:tethering_service:s0 tclass=service_manager permissive=0
2021-09-13 10:25:32.798 7821-7821/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Landroid/app/Application;->mLoadedApk:Landroid/app/LoadedApk; (greylist, reflection, allowed)
2021-09-13 10:25:32.798 7821-7821/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Landroid/app/LoadedApk;->mActivityThread:Landroid/app/ActivityThread; (greylist, reflection, allowed)
2021-09-13 10:25:32.798 7821-7821/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden field Landroid/app/ActivityThread;->mActivities:Landroid/util/ArrayMap; (greylist, reflection, allowed)
2021-09-13 10:25:32.812 7821-7983/com.ximalaya.ting.lite I/crashsdk: version unique build id: 864a0d01
2021-09-13 10:25:32.816 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getDeviceId:-1
2021-09-13 10:25:32.820 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getSubscriberId:-1
2021-09-13 10:25:32.823 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getDeviceId:-1
2021-09-13 10:25:32.822 7821-7821/com.ximalaya.ting.lite W/com.ximalaya.ting.lite: type=1400 audit(0.0:320048): avc: denied { read } for comm=4173796E635461736B202332 name="version" dev="proc" ino=4026532129 scontext=u:r:untrusted_app_27:s0:c512,c768 tcontext=u:object_r:proc_version:s0 tclass=file permissive=0 app=com.ximalaya.ting.lite
2021-09-13 10:25:32.826 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getDeviceId:-1
2021-09-13 10:25:32.829 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.832 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.839 7821-7821/com.ximalaya.ting.lite I/crashsdk: Catcher mask: 1000, 4096
2021-09-13 10:25:32.840 7821-7821/com.ximalaya.ting.lite I/crashsdk: Catcher thread 7831
2021-09-13 10:25:32.840 7821-7821/com.ximalaya.ting.lite D/crashsdk: Register ANR handler ...
2021-09-13 10:25:32.842 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.849 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getSubscriberId:-1
2021-09-13 10:25:32.850 7821-7975/com.ximalaya.ting.lite W/alaya.ting.lit: Accessing hidden method Landroid/telephony/TelephonyManager;->getSubscriberId(I)Ljava/lang/String; (greylist-max-p, reflection, allowed)
2021-09-13 10:25:32.852 7821-7895/com.ximalaya.ting.lite I/crashsdk: begin hack android.os.Process
2021-09-13 10:25:32.852 7821-7895/com.ximalaya.ting.lite I/crashsdk: end hack android.os.Process
2021-09-13 10:25:32.852 7821-7895/com.ximalaya.ting.lite I/crashsdk: LibcMalloc detail: disabled.
2021-09-13 10:25:32.852 3261-3861/? E/PhoneInterfaceManager: [PhoneIntfMgr] getCarrierPrivilegeStatusForUid: No UICC
2021-09-13 10:25:32.854 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getSubscriberId:0
2021-09-13 10:25:32.859 7858-7982/com.ximalaya.ting.lite I/url123: http://mobile.ximalaya.com/mobile/nonce/app
2021-09-13 10:25:32.866 7821-7989/com.ximalaya.ting.lite D/crashsdk: Native log stat thread 7989 setup, waiting
2021-09-13 10:25:32.868 3261-3861/? E/PhoneInterfaceManager: [PhoneIntfMgr] getCarrierPrivilegeStatusForUid: No UICC
2021-09-13 10:25:32.870 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getSubscriberId:1
2021-09-13 10:25:32.873 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getMeidForSlot:-1
2021-09-13 10:25:32.874 604-604/? E/SELinux: avc:  denied  { find } for pid=4536 uid=10266 name=tethering scontext=u:r:vendor_systemhelper_app:s0:c512,c768 tcontext=u:object_r:tethering_service:s0 tclass=service_manager permissive=0
2021-09-13 10:25:32.876 7821-7975/com.ximalaya.ting.lite D/TelephonyManager: getMeid: return null because MEID is not available
2021-09-13 10:25:32.876 7858-7929/com.ximalaya.ting.lite I/DeviceUtile: ###########&&&&&&uuid=====================cbf5e222-d5ea-3d49-80bd-aebaba0eb5cf
2021-09-13 10:25:32.879 7858-7982/com.ximalaya.ting.lite I/DeviceUtile: ###########&&&&&&uuid=====================cbf5e222-d5ea-3d49-80bd-aebaba0eb5cf
2021-09-13 10:25:32.880 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getMeidForSlot:-1
2021-09-13 10:25:32.880 7821-7975/com.ximalaya.ting.lite D/TelephonyManager: getMeid: return null because MEID is not available
2021-09-13 10:25:32.881 7858-7979/com.ximalaya.ting.lite I/MMKV: <native-bridge.cpp:101::JNI_OnLoad> current API level = 30
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/MMKV: <MMKV.cpp:156::initialize> version v1.2.4 page size:4096
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/MMKV: <MMKV.cpp:198::initializeMMKV> root dir: /data/user/0/com.ximalaya.ting.lite/files/mmkv
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:81::loadFromFile> loading [xm_log_mmkv] with 532 actual size, file size 4096, InterProcess 1, meta info version:3
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:86::loadFromFile> loading [xm_log_mmkv] with crc 1764967406 sequence 1 version 3
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:130::loadFromFile> loaded [xm_log_mmkv] with 1 key-values
2021-09-13 10:25:32.882 7858-7979/com.ximalaya.ting.lite I/XmMMKV_BaseMMKV: create MMKV instance: com.tencent.mmkv.MMKV@fd90eeb
2021-09-13 10:25:32.885 7858-7982/com.ximalaya.ting.lite I/MMKV: <MMKV.cpp:198::initializeMMKV> root dir: /data/user/0/com.ximalaya.ting.lite/files/mmkv
2021-09-13 10:25:32.885 7858-7982/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:81::loadFromFile> loading [mmkv_xima_lite_core] with 3084 actual size, file size 4096, InterProcess 1, meta info version:3
2021-09-13 10:25:32.885 7858-7982/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:86::loadFromFile> loading [mmkv_xima_lite_core] with crc 4058057122 sequence 9 version 3
2021-09-13 10:25:32.886 7858-7982/com.ximalaya.ting.lite I/MMKV: <MMKV_IO.cpp:130::loadFromFile> loaded [mmkv_xima_lite_core] with 30 key-values
2021-09-13 10:25:32.886 7858-7982/com.ximalaya.ting.lite I/XmMMKV_BaseMMKV: create MMKV instance: com.tencent.mmkv.MMKV@d9292e1
2021-09-13 10:25:32.887 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getMeidForSlot:-1
2021-09-13 10:25:32.889 7821-7975/com.ximalaya.ting.lite D/TelephonyManager: getMeid: return null because MEID is not available
2021-09-13 10:25:32.901 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.910 3261-3861/? W/TelephonyPermissions: reportAccessDeniedToReadIdentifiers:com.ximalaya.ting.lite:getImeiForSlot:-1
2021-09-13 10:25:32.954 7858-7965/com.ximalaya.ting.lite I/HttpDNSInterceptor: useOldPolicy http://mobile.ximalaya.com/mobile/nonce/app
2021-09-13 10:25:32.974 7858-7979/com.ximalaya.ting.lite I/System.out: 2
2021-09-13 10:2


