 private void initHeaderRv() {
        mCircleRadioRv = findViewById(R.id.main_onekey_radio_play_header_rv);
        mCircleRadioRv.setDisallowInterceptTouchEventView(getSlideView());
        mCircleAdapter = new NewUserQuickListenCardItemAdapter(this);
        mCircleRadioRv.setAdapter(mCircleAdapter);
        mCircleRadioRv.addItemDecoration(new LinearItemDecoration(BaseUtil.dp2px(mContext, 10), BaseUtil.dp2px(mContext, 10)));
        Path path = new Path();
        int length = BaseUtil.dp2px(mContext, 105);//两个item中心弧长
        float lengthSwipe = 10f; // length对应的弧度
        float radius = (float) (length * 180f / Math.PI / lengthSwipe);
        float swipeHalf = fixAngle((float) (Math.asin((BaseUtil.getScreenWidth(mContext) / 2f / radius)) * 180F / Math.PI));
        float startAngle = 90 + swipeHalf;

        float x = BaseUtil.getScreenWidth(mContext) / 2f;
        //100 RecyclerView高度一半
        float y = BaseUtil.dp2px(mContext, 100) - radius;

        RectF oval = new RectF(x - radius, y - radius, x + radius, y + radius);
        path.addArc(oval, startAngle, -1 * swipeHalf * 2);

        //使用path创建mLayoutManager
        mLayoutManager = new PathLayoutManager(path, BaseUtil.dp2px(mContext, 105), RecyclerView.HORIZONTAL);
        mLayoutManager.setItemDirectionFixed(false); // 保持垂直
//        mLayoutManager.setItemScaleRatio(0.9f, 0, 1f, 0.5f, 0.9f, 1f);

        mLayoutManager.setScrollMode(PathLayoutManager.SCROLL_MODE_LOOP);
        mLayoutManager.setAutoSelect(true);
        mLayoutManager.setItemDirectionFixed(true);

        //RecylerView设置PathLayoutManager
        mCircleRadioRv.setLayoutManager(mLayoutManager);

        //刻度线View
        OneKeyRadioPlayCircleView circleView = findViewById(R.id.main_onekey_radio_play_header_circle_view);
        // final Path path1 = new Path();
        //radius = radius + BaseUtil.dp2px(mContext, 100);
        //RectF oval1 = new RectF(x - radius, y - radius, x + radius, y + radius);
        //path1.addArc(oval1, startAngle, -1 * swipeHalf * 2);

        mLayoutManager.setItemChangeListener(new PathLayoutManager.ItemChangeListener() {
            @Override
            public void itemChange(View item, float angle, float fraction) {
                Logger.i(TAG, "itemChange");
                if (item instanceof CardItemView) {
                    ((CardItemView) item).updateView(fixAngleForTan(angle));
                }
//                item.setRotation(angle / 2f);
            }

            @Override
            public void scrollChange(float fraction) {
                Logger.i(TAG, "scrollChange");
                //重绘刻度线
                circleView.drawCircle(fraction * 360, (int) (y + BaseUtil.dp2px(mContext, 200 - 70)));
            }
        });
        mLayoutManager.setOnItemSelectedListener(new PathLayoutManager.OnItemSelectedListener() {
            @Override
            public void onSelected(int position) {
                QuickListenModel model = mCircleAdapter.getItemData(position);
                if (model == null) {
                    return;
                }
                Logger.d(TAG, "onSelected: " + model.getTitle());
                if (ConstantsOpenSdk.isDebug) {
                    CustomToast.showToast(model.getTitle());
                }
                scrollAndShowPage(model);
            }
        });
    }