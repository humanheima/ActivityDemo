投放？只有第一次安装的时候会执行







MainActivity 的首次`onResume`方法

```java
//获取粘贴板
ShareCommandManager.obtainRealXmCommandForClip(new ShareCommandManager.ObtainClipXmCommandCallBack() {
    @Override
    public void onObtainClipXmCommandFinish(String realCommand) {
        if (finalIsFirstResumed) {//冷启动
            //注释1处，缓存冷启动串码
            ChannelInfoRecordManager.cacheColdBootXmRealCommend(realCommand);

            //注释2处，处理冷启动，相关弹框等优先级
            dealWithFirstStartDialog(realCommand);

            //处理更新弹框
            mastPriorityCheckUpdate();

            //上报冷启动，冷启动上报，增长部门专用
            ChannelInfoRecordManager.asyncRecordStartup(true, realCommand);
            //注释3处，将串码缓存本地供播放进程数据上报的时候使用
            ChannelInfoRecordManager.cacheCommendForPlayProcessUse(realCommand);
            FuliLogger.log("app切换到前台====main----onResume--冷启动");
        } else {
            if (ChannelInfoRecordManager.isFromAppGoToForegroundStatus()) {
                //清除切换前台记录的状态
                ChannelInfoRecordManager.deleteAppGoToForegroundStatus();
                //上报热启动，如果在其他activity，那从其他activity切回到main的时候进行上报
                ChannelInfoRecordManager.asyncRecordStartup(false, realCommand);
                //将串码缓存本地供播放进程数据上报的时候使用
                ChannelInfoRecordManager.cacheCommendForPlayProcessUse(realCommand);
                //注释4处，热启动处理串码检测，解析跳转等
                checkCommandIting(realCommand);

                //好评需求保存活跃天数，每次热启动也重新检测一次活跃天数，判断是否需要保存
                MarkGiveGuideManager.saveMarketUserNativeDayCount();

                FuliLogger.log("app切换到前台====main----onResume--热启动");

                //后台切换到前天，检测是否弹出0.3元
                OneYuanExtractMoneyManager.getInstance().checkCanShowOneYuanExtractMoney();
            } else {
                //从app内的activity跳转切换到main，并非后台切前台操作，不进行上报和检测
                FuliLogger.log("app切换到前台====main----onResume--无效热启动");
            }
        }
    }
});
```

注释1处，缓存冷启动串码。

注释2处，处理投放，串码，兴趣卡片等。

```java
private void dealWithFirstStartDialog(String realCommand) {
    PutInActiveUtingManager.getInstance().checkAndHandlePutInUting(MainActivity.this, new PutInActiveUtingManager.CheckAndCanNextListener() {
        @Override
        public void onCanNext() {
            if (isFinishing()) {
                return;
            }
            if (isDestroyed) {
                return;
            }
            //注释1处，处理过投放的uting了，之后串码和画像等
            if (!checkCommandIting(realCommand)) {
                //走新兴趣卡片，领钱等需要依赖配置中心的链式操作
                //确保需要的数据，已经能从配置中心拿到以后才开始走流程
                MainActivityConfigCenterManager.getInstance().checkConfigCenterSuccess(new MainActivityConfigCenterManager.LoadConfigCenterListener() {
                    @Override
                    public void loadConfigCenterSuccess() {
                        if (isFinishing()) {
                            return;
                        }
                        if (isDestroyed) {
                            return;
                        }
                        requestIsInterestCardOfHomepage();
                    }

                    @Override
                    public void loadConfigCenterError() {
                        if (isFinishing()) {
                            return;
                        }
                        if (isDestroyed) {
                            return;
                        }
                        requestIsInterestCardOfHomepage();
                    }
                });
            }
        }
    });
}
```

注释1处，处理过投放的uting了，这里处理串码，感觉这里有问题呀，好像有串码的时候，都会返回true。


```java
public boolean checkCommandIting(final String realCommand) {
    if (TextUtils.isEmpty(realCommand)) {
        return false;
    }
    if (isCheckingITing) {
        return false;
    }
    isCheckingITing = true;
    //解密串码
    CommonRequestM.decodeShareCommand(realCommand, new IDataCallBack<ShareCommand>() {
        @Override
        public void onSuccess(@Nullable ShareCommand object) {
            isCheckingITing = false;
            if (object == null) {
                return;
            }
            //注释1处，串码解析请求成功，清除粘贴板信息
            ClipManager.clearClipboard();
            String url = object.getLink();
            if (TextUtils.isEmpty(url)) {
                return;
            }
            new XMTraceApi.Trace()
                    .setMetaId(5141)
                    .setServiceId("commandOpenSucceed")
                    .put("command", realCommand)
                    .put("srcPageUrl", url)
                    .createTrace();
            String rawIting = ShareCommandManager.parseUrl(url);
            if (TextUtils.isEmpty(rawIting)) {
                return;
            }

            //注释2处，检测串码对应的uting是否需要进行模式切换
            if (CheckUtingAppModeManager.checkUtingNeedChangeToTruckMode(rawIting)) {
                CheckUtingAppModeManager.runAppModeChangeForUting(MainActivity.this, AppModeGlobalChangeManager.MODE_TRUCK_FRIEND, new CheckUtingAppModeManager.ICheckUtingAppModeListener() {
                    @Override
                    public void onCheckUtingAppModeFinih() {
                        MainActivity.this.handleIting(rawIting, object);

                        AppModeManager.traceModeSelectAfterSuccess("1");
                    }
                });
            } else if (CheckUtingAppModeManager.checkUtingNeedChangeToNormalMode(rawIting)) {
                CheckUtingAppModeManager.runAppModeChangeForUting(MainActivity.this, AppModeGlobalChangeManager.MODE_NORMAL_DEF, new CheckUtingAppModeManager.ICheckUtingAppModeListener() {
                    @Override
                    public void onCheckUtingAppModeFinih() {
                        MainActivity.this.handleIting(rawIting, object);

                        AppModeManager.traceModeSelectAfterSuccess("1");
                    }
                });
            } else {
                //注释3处，正常处理uting。
                MainActivity.this.handleIting(rawIting, object);
            }
        }

        @Override
        public void onError(int code, String message) {
            isCheckingITing = false;
        }
    });
    return true;
}
```

注释1处，串码解析请求成功，清除粘贴板信息。
注释2处，检测串码对应的uting是否需要进行模式切换。
注释3处，正常处理uting。



