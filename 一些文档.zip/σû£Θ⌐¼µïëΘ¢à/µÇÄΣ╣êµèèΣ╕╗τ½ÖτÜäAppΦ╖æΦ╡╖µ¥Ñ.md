* 怎么把主站的项目跑起来？

1. 将 MainBundle TingMainHost  XAndroidFrameWork 拷贝到同一个目录下，比如叫main_project。

2. 将所有的模块切检出origin/Canary分支。

3. XAndroidFrameWork/AndroidStudioGradleRelyFile目录下的所有内容拷贝到main_project。

4. 使用Android Studio打开main_project，在local.properties

```
## This file must *NOT* be checked into Version Control Systems,
# as it contains information specific to your local configuration.
#
# Location of the SDK. This is only used by Gradle.
# For customization when using a Version Control System, please read the
# header note.
#Mon Dec 13 14:36:02 CST 2021
sdk.dir=/Users/xmly/Library/Android/sdk
buildFast=true
DEV_BUNDLE_MODE=true
#BUILD_IN_BUNDLE=main,login,search,mylisten,live,video
BUILD_IN_BUNDLE=main,search
BUILD_SO_BUNDLE=
SYNC_BUNDLE=live,reactnative,feed,record
BUNDLE_VERSION=3124.234
```