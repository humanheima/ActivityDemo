管理位图内存

* 从 Android 3.0（API 级别 11）到 Android 7.1（API 级别 25），像素数据会与关联的位图一起存储在 Dalvik 堆上。
* 在 Android 8.0（API 级别 26）及更高版本中，位图像素数据存储在原生堆中。



参考链接：

* [管理位图内存](https://developer.android.google.cn/topic/performance/graphics/manage-memory)
