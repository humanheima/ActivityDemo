### 打热修复包

比如我们要打3884这个构建的热修复。我们直接选择rebuid，选择已经修复了问题的分支比如叫`feature_hot_fix_one`。

构建参数 `CreateBaseApk=false`，`CreatePatchApk=true`，填入`LoarJarNum=3884`。

然后 rebuild。