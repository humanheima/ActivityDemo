## Kotlin 一些使用技巧


### 使用 lambda表达式替代函数式接口

```kotlin
    var onDetailClickListener: ((url: String) -> Unit)? = null
```

在Java中使用

```java
noticeView.setOnDetailClickListener(new Function1<String, Unit>() {
                @Override
                public Unit invoke(String url) {
                    if (canUpdateUi()) {
                        ToolUtil.clickUrlAction(HomeRecommendFragment.this, url, null);
                    }
                    return null;
                }
            });
```