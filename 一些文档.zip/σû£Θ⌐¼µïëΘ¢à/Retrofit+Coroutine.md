协程

统一处理 code和msg



### 参考的文章


这个感觉可以
* [优雅的封装网络请求，协程 + Retrofit](https://juejin.cn/post/6959115482511343647)



项目没跑起来

* [Android Kotlin + 协程 + Retrofit + MVVM优雅的实现网络请求(简洁！！！)](https://juejin.cn/post/6922638287806922759)



* [一步步封装实现自己的网络请求框架 3.0](https://juejin.cn/post/6932650811642085389)