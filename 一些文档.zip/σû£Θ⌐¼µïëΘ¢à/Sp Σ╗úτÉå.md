### Sp 代理

 ### 保存
 
内部直接调用mmkv保存就行了。
 
 ```java
 public void saveFloat(String key, float value) {
        MmkvCommonUtil.getInstance(mAppContext).saveFloat(key, value);
        //apply(settings.edit().putFloat(key, value));
}
 ```
 
 ### 获取
 
 ```java
 public float getFloat(String key) {
        if (MmkvCommonUtil.getInstance(mAppContext).containsKey(key)){
            return MmkvCommonUtil.getInstance(mAppContext).getFloat(key, -1);
        }
        return settings.getFloat(key, -1);
}
 ```
 