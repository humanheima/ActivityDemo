H5打开本地的某个界面都是从OpenLinkAction开始的

```java
public class OpenLinkAction extends BaseAction {
    @Override
    public boolean needStatRunloop() {
        return false;
    }

    @Override
    public void doAction(IhybridContainer hybridContainer, JSONObject args, AsyncCallback callback, Component comp, String scheme) {
        super.doAction(hybridContainer, args, callback, comp, scheme);
        final String url = args.optString("url");
        if (TextUtils.isEmpty(url)) {
            callback.callback(NativeResponse.fail(-1, "params error"));
            return;
        }

        Intent intent = new Intent();
        intent.setData(Uri.parse(url));
        //调用startPage
        callback.callback(hybridContainer.startPage(intent));
    }
}
```

然后是HybridFragment的startPage方法

```java
@Override
public NativeResponse startPage(Intent intent) {
    return startPage(intent, null);
}
```

```java
    private NativeResponse startPage(Intent intent, IhybridContainer.PageCallback callback) {
        Uri uri = intent.getData();
        if (uri == null) {
            return NativeResponse.fail();
        }
        if (!uri.isOpaque()) {
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (HybridView.HOST_COMPONENT.equals(host) || "http".equals(scheme) || "https".equals(scheme)) {
                String pageKey = intent.getStringExtra("key");
                String overlay = intent.getStringExtra("overlay");
                boolean fullscreen = intent.getBooleanExtra("fullscreen", false);
                Bundle bundle = new Bundle();
                bundle.putParcelable("loadUrl", uri);
                bundle.putString(BundleKeyConstants.KEY_EXTRA_URL, uri.toString());
                bundle.putString("overlay", overlay);
                bundle.putBoolean("fullscreen", fullscreen);

                HybridFragment targetFragment = new NativeHybridFragment();
                targetFragment.setArguments(bundle);
                if (!TextUtils.isEmpty(pageKey) || !PageStackManager.isStackEmpty()) {
                    PageStackManager.insertComponentPage(targetFragment, uri, pageKey);
                }
                if (callback != null) {
                    pageCallback = callback;
                    targetFragment.setCallbackFinish(this);
                }
                String direction = intent.getStringExtra("direction");
                int inAnim = "btt".equals(direction) ? R.anim.host_slide_in_bottom : R.anim.host_slide_in_right;
                int outAnim = "btt".equals(direction) ? R.anim.host_slide_out_bottom : R.anim.host_slide_out_right;
                startFragment(targetFragment, inAnim, outAnim);
                return NativeResponse.success();
                
            } else if ("uting".equals(uri.getScheme()) || "iting".equals(uri.getScheme())) {
                //注释1处
                try {
                    boolean result = Router.getMainActionRouter().getFunctionAction().handleIting(getActivity(), uri);
                    if (result) {
                        return NativeResponse.success();
                    }
                } catch (Exception e) {

                }
            }
        }
        //注释2处
        startActivity(intent);
        return NativeResponse.success();
    }

```

注释1处，处理uting和iting打开本地界面

如果最后调用了注释2处，会调用MainActivity的onNewIntent方法。


Intent { dat=uting://open?msg_type=505 flg=0x10000000 cmp=com.ximalaya.ting.lite/com.ximalaya.ting.android.host.activity.MainActivity }