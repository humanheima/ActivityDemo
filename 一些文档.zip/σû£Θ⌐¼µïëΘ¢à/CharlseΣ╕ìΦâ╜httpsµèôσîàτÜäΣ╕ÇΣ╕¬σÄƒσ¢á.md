### Charles不能https抓包解决方案

* 一个原因就是手机无法正确的安装证书。

#### 下载Charles证书

一些手机真的是恶心，比如小米。1. 浏览器无法下载Charles的证书。是通过UC浏览器下载的证书。

#### 安装Charles证书

以小米手机为例：打开设置->密码与安全->系统安全->加密与凭据->安装证书
然后这个时候有3个选项：

* CA 证书
* VPN和应用用户证书
* 证书

无法在**CA 证书**和**VPN和应用用户证书**这两个选项下安装证书。需要你输入PIN码啥的，但是你如果用的是公司的测试机，这些账号，PIN码啥的真的不知道。

只能从**证书**这个选项下，从UC浏览器的下载目录中选择下载的证书安装。但是安装完以后无法在**信任的凭据**中看到。

设置->密码与安全->系统安全->加密与凭据->信任的凭据

* 系统：这个选项下是信任的系统的证书
* 用户： 这个选项下是信任的用户安装的证书（正常我们自己安装的证书应该在这里出现）

注意：如果我们的证书安装完毕以后能在信任的凭据下的用户分类下看到，那么应该可以正常抓https包。

最后我们安装到的证书在设置->密码与安全->系统安全->加密与凭据->用户凭据下可以看到：


### 在无法正确安装证书的情况下，如何https抓包

Google官方给出了解决方案[Network security configuration](https://developer.android.google.cn/training/articles/security-config?hl=en)，可以在不修改应用代码的情况下使用一种安全的声明式的配置文件来自定义安全的网络配置。

我们省略其他内容。我们想要的是在测试环境下，抓我们自己应用的https包。实现步骤：

1. 在AndroidManifest.xml文件中修改`application`标签。

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"

    <application android:networkSecurityConfig="@xml/network_security_config"
                    
    </application>

</manifest>
```

2. 在`res/xml`目录下新建`network_security_config.xml`，内容如下：

```xml
<network-security-config>
    <base-config cleartextTrafficPermitted="true" />

    <!--在debug模式下-->
    <debug-overrides>
        <trust-anchors>
            <!--信任用户添加的证书(在手机中受信任的凭据中用户分类下看到的证书) -->
            <certificates src="user" />
            <!--信任用户额外的证书-->
            <certificates src="@raw/charles_ssl_proxying_certificate" />
        </trust-anchors>
    </debug-overrides>

</network-security-config>
```


* [Network security configuration](https://developer.android.google.cn/training/articles/security-config?hl=en)
* 
* [Android Network Security Configuration Codelab](https://developer.android.google.cn/codelabs/android-network-security-config?hl=en#0)






